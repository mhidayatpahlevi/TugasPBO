# Tugas-PBO
1. MEMBUAT PERULANGAN MENGGUNAKAN PYTHON
   source code :
   nama = "Dayat"

for i in range(1, 101):
    print(i)
    if i % 10 == 0:
        for _ in range(3):
            print(nama)
Penjelasan :
Menginisialisasi variabel nama dengan nilai "Dayat".
Memulai sebuah perulangan dengan range(1, 101) yang akan mencetak angka dari 1 hingga 100.
Setiap kali mencetak angka, kode memeriksa apakah angka tersebut habis dibagi 10 (i % 10 == 0). Jika benar (artinya mencapai kelipatan 10), maka dilakukan sebuah perulangan dalam perulangan (for _ in range(3):) yang akan mencetak nama "Dayat" sebanyak 3 kali.

2. membuat program bebas, dengan menerapkan if else pada:
  a. For Loops
source code :
print("Menggunakan For Loop:")
for i in range(-5, 6):
    if i >= 0:
        print(f"{i} adalah bilangan positif")
    else:
        print(f"{i} adalah bilangan negatif")
penjelasan :
Dalam program ini akan mengecek bilangan dari -5 hingga 5 menggunakan for loop. Setiap bilangan yang non-negatif (nol atau lebih besar) akan dicetak sebagai bilangan positif, sedangkan bilangan negatif akan dicetak sebagai bilangan negatif.

  b. While Loops
  source code :
# While Loop dengan if else (bilangan ganjil/genap)
print("Menggunakan While Loop:")
j = 1
while j <= 10:
    if j % 2 == 0:
        print(f"{j} adalah bilangan genap")
    else:
        print(f"{j} adalah bilangan ganjil")
    j += 1
penjelasan :
pada program ini akan mencetak bilangan dari 1 hingga 10 beserta pengecekan apakah bilangan tersebut ganjil atau genap menggunakan pernyataan if else.

3. Buatlah sebuah variabel dengan tipe data array, kemudian tampilkan semua nilai dalam variabel tersebut menggunakan perulangan for
  source code :
nilai = [10, 20, 30, 40, 50]

for item in nilai:
    print(item)
penjelasan :
dalam program ini nilai adalah sebuah list yang berisi beberapa angka. Perulangan for digunakan untuk mengakses setiap elemen dalam list nilai dan kemudian mencetak nilainya satu persatu.
